/////////////////////////////////////////////////////////////////////////////////////////////////////
///	
///  @file       main.m
///  @copyright  Copyright © 2019 小灬豆米. All rights reserved.
///  @brief      main
///  @date       2019/6/23
///  @author     小灬豆米
///
/////////////////////////////////////////////////////////////////////////////////////////////////////

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
